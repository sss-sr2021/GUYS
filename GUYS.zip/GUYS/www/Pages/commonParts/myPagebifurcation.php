<?php

/*

myPagebifurcation.php:マイページを押したときの分岐

Author:秦伊吹
Version:0.0.1
Created:2021.05.21（）
updated:

*/

    require_once './functions.php';
    session_start();
    myPageBi();