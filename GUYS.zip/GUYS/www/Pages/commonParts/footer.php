<?php
/*
 * header.php :ヘッダー部分の共通化
 * 
 * Author:伊藤明洋
 * Version :0.0.1
 * create :2021.05.20
 * Update :2021.05.20 伊藤
 * 
 * 
*/
?>

    <footer>
        <ul class="ulfooter">
            <li><a href="top.php">TOP</a></li>
            <li><a href="company.php">漢委員会</a></li>
            <li><a href="privacy.php">プライパシーポリシー</a></li>
        </ul>
        <p class="copyright">Copyright © 2021 チーム漢. All rights reserved.</p>
    </footer>
     </div>
 </body>
</html>